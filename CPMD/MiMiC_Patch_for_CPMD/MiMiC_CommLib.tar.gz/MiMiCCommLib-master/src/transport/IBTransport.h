//
// Created by vbolnykh on 6/4/18.
//

#ifndef MIMICCOMMLIB_IBTRANSPORT_H
#define MIMICCOMMLIB_IBTRANSPORT_H

#include "Transport.h"
#include "DataTypes.h"
#include <infiniband/verbs.h>

class IBTransport : public Transport {

};


#endif //MIMICCOMMLIB_IBTRANSPORT_H
